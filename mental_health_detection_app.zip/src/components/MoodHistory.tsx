import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function MoodHistory() {
  const moodEntries = useQuery(api.mentalHealth.getUserMoodEntries, { limit: 20 });

  if (!moodEntries) {
    return (
      <div className="flex justify-center items-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (moodEntries.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="text-gray-400 text-4xl mb-4">📊</div>
        <h3 className="text-lg font-medium text-gray-700 mb-2">No mood entries yet</h3>
        <p className="text-gray-500">Start by creating your first mood entry!</p>
      </div>
    );
  }

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case "low": return "bg-green-100 text-green-800";
      case "moderate": return "bg-yellow-100 text-yellow-800";
      case "high": return "bg-orange-100 text-orange-800";
      case "critical": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getMoodEmoji = (mood: string) => {
    const emojiMap: Record<string, string> = {
      very_happy: "😄",
      happy: "😊",
      neutral: "😐",
      sad: "😢",
      very_sad: "😭",
      anxious: "😰",
      stressed: "😤",
    };
    return emojiMap[mood] || "😐";
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Your Mood History</h2>
      
      <div className="space-y-4">
        {moodEntries.map((entry) => (
          <div key={entry._id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{getMoodEmoji(entry.mood)}</span>
                <div>
                  <div className="font-medium text-gray-800 capitalize">
                    {entry.mood.replace("_", " ")}
                  </div>
                  <div className="text-sm text-gray-500">
                    {new Date(entry._creationTime).toLocaleDateString()} at{" "}
                    {new Date(entry._creationTime).toLocaleTimeString()}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRiskColor(entry.riskLevel)}`}>
                  {entry.riskLevel} risk
                </span>
                <span className="text-sm font-medium text-gray-600">
                  {Math.round(entry.riskScore)}
                </span>
              </div>
            </div>
            
            <p className="text-gray-700 mb-3">{entry.text}</p>
            
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-1">
                <span className="text-gray-500">Sentiment:</span>
                <span className={`font-medium ${
                  entry.sentiment.label === "positive" ? "text-green-600" :
                  entry.sentiment.label === "negative" ? "text-red-600" : "text-gray-600"
                }`}>
                  {entry.sentiment.label}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-gray-500">Confidence:</span>
                <span className="font-medium text-gray-700">
                  {Math.round(entry.sentiment.confidence * 100)}%
                </span>
              </div>
            </div>

            {entry.recommendations && entry.recommendations.length > 0 && (
              <div className="mt-3 pt-3 border-t border-gray-200">
                <div className="text-sm font-medium text-gray-700 mb-2">Recommendations:</div>
                <ul className="text-sm text-gray-600 space-y-1">
                  {entry.recommendations.slice(0, 2).map((rec, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="text-blue-500 mt-1">•</span>
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
