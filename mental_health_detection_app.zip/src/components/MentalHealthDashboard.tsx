import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { MoodEntryForm } from "./MoodEntryForm";
import { MoodHistory } from "./MoodHistory";
import { RiskScoreDisplay } from "./RiskScoreDisplay";
import { VoiceAnalysis } from "./VoiceAnalysis";
import { VideoAnalysis } from "./VideoAnalysis";

export function MentalHealthDashboard() {
  const [activeTab, setActiveTab] = useState<"entry" | "history" | "voice" | "video">("entry");
  const userProfile = useQuery(api.mentalHealth.getUserProfile);
  const recentEntries = useQuery(api.mentalHealth.getUserMoodEntries, { limit: 5 });

  const tabs = [
    { id: "entry", label: "Daily Check-in", icon: "📝" },
    { id: "history", label: "History", icon: "📊" },
    { id: "voice", label: "Voice Analysis", icon: "🎤" },
    { id: "video", label: "Video Analysis", icon: "📹" },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Welcome to your Mental Health Dashboard</h1>
        <p className="text-gray-600">Track your mental wellbeing with AI-powered analysis</p>
        
        {userProfile && (
          <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="text-sm text-blue-600 font-medium">Average Risk Score</div>
              <div className="text-2xl font-bold text-blue-800">
                {Math.round(userProfile.averageRiskScore)}
              </div>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <div className="text-sm text-green-600 font-medium">Total Check-ins</div>
              <div className="text-2xl font-bold text-green-800">
                {recentEntries?.length || 0}
              </div>
            </div>
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="text-sm text-purple-600 font-medium">Last Check-in</div>
              <div className="text-sm font-medium text-purple-800">
                {userProfile.lastCheckIn 
                  ? new Date(userProfile.lastCheckIn).toLocaleDateString()
                  : "Never"
                }
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Risk Score Display */}
      {recentEntries && recentEntries.length > 0 && (
        <RiskScoreDisplay entry={recentEntries[0]} />
      )}

      {/* Navigation Tabs */}
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? "bg-blue-50 text-blue-600 border-b-2 border-blue-600"
                    : "text-gray-500 hover:text-gray-700 hover:bg-gray-50"
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "entry" && <MoodEntryForm />}
          {activeTab === "history" && <MoodHistory />}
          {activeTab === "voice" && <VoiceAnalysis />}
          {activeTab === "video" && <VideoAnalysis />}
        </div>
      </div>
    </div>
  );
}
