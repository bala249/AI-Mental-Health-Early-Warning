import { useState } from "react";
import { useMutation, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function MoodEntryForm() {
  const [text, setText] = useState("");
  const [mood, setMood] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const analyzeSentiment = useAction(api.mentalHealth.analyzeSentiment);
  const calculateRiskScore = useAction(api.mentalHealth.calculateRiskScore);
  const createMoodEntry = useMutation(api.mentalHealth.createMoodEntry);

  const moodOptions = [
    { value: "very_happy", label: "Very Happy", emoji: "😄", color: "bg-green-500" },
    { value: "happy", label: "Happy", emoji: "😊", color: "bg-green-400" },
    { value: "neutral", label: "Neutral", emoji: "😐", color: "bg-gray-400" },
    { value: "sad", label: "Sad", emoji: "😢", color: "bg-yellow-500" },
    { value: "very_sad", label: "Very Sad", emoji: "😭", color: "bg-red-400" },
    { value: "anxious", label: "Anxious", emoji: "😰", color: "bg-orange-500" },
    { value: "stressed", label: "Stressed", emoji: "😤", color: "bg-red-500" },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !mood) {
      toast.error("Please fill in all fields");
      return;
    }

    setIsSubmitting(true);
    try {
      // Analyze sentiment
      const sentiment = await analyzeSentiment({ text });
      
      // Calculate risk score
      const riskData = await calculateRiskScore({ sentiment });
      
      // Create mood entry
      await createMoodEntry({
        text,
        mood,
        sentiment,
        riskScore: riskData.riskScore,
        riskLevel: riskData.riskLevel,
        recommendations: riskData.recommendations,
      });

      toast.success("Mood entry saved successfully!");
      setText("");
      setMood("");
    } catch (error) {
      toast.error("Failed to save mood entry");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-800 mb-4">How are you feeling today?</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Mood Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Select your current mood
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {moodOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => setMood(option.value)}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    mood === option.value
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="text-2xl mb-1">{option.emoji}</div>
                  <div className="text-xs font-medium text-gray-700">{option.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Text Input */}
          <div>
            <label htmlFor="feelings" className="block text-sm font-medium text-gray-700 mb-2">
              Tell us more about your feelings
            </label>
            <textarea
              id="feelings"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Describe how you're feeling today, what's on your mind, or any concerns you have..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
              rows={4}
              required
            />
            <div className="text-xs text-gray-500 mt-1">
              {text.length}/500 characters
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting || !text.trim() || !mood}
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isSubmitting ? (
              <div className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Analyzing...
              </div>
            ) : (
              "Analyze My Mood"
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
