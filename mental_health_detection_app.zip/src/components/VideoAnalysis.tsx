import { useState, useRef, useEffect } from "react";
import { useMutation, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function VideoAnalysis() {
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  
  const generateUploadUrl = useMutation(api.mentalHealth.generateUploadUrl);

  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 }, 
        audio: false 
      });
      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      toast.error("Could not access camera");
      console.error(error);
    }
  };

  const startRecording = async () => {
    if (!stream) {
      await startCamera();
      return;
    }

    try {
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "video/webm" });
        setVideoBlob(blob);
      };

      mediaRecorder.start();
      setIsRecording(true);
      
      // Auto-stop after 15 seconds
      setTimeout(() => {
        if (mediaRecorderRef.current && isRecording) {
          stopRecording();
        }
      }, 15000);
      
    } catch (error) {
      toast.error("Could not start recording");
      console.error(error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const analyzeVideo = async () => {
    if (!videoBlob) return;

    setIsAnalyzing(true);
    try {
      // Upload video file
      const uploadUrl = await generateUploadUrl();
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": videoBlob.type },
        body: videoBlob,
      });
      
      if (!result.ok) {
        throw new Error("Upload failed");
      }

      const { storageId } = await result.json();

      // Simulate video analysis (in a real app, you'd use actual AI models like DeepFace)
      const mockAnalysis = {
        faceEmotions: {
          happy: 0.15,
          sad: 0.45,
          angry: 0.05,
          fear: 0.20,
          surprise: 0.05,
          disgust: 0.02,
          neutral: 0.08,
        },
        facialFeatures: {
          eyeContact: 0.7, // 70% eye contact
          smileIntensity: 0.2, // 20% smile intensity
          overallExpression: "concerned",
        },
      };

      setAnalysisResult({
        videoFileId: storageId,
        ...mockAnalysis,
      });

      toast.success("Video analysis complete!");
    } catch (error) {
      toast.error("Failed to analyze video");
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetRecording = () => {
    setVideoBlob(null);
    setAnalysisResult(null);
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-800 mb-2">Facial Expression Analysis</h2>
        <p className="text-gray-600 mb-6">
          Record a short video to analyze your facial expressions and emotional state
        </p>

        {/* Video Interface */}
        <div className="bg-gray-50 rounded-xl p-6">
          <div className="max-w-md mx-auto">
            {!videoBlob ? (
              <div className="space-y-4">
                {/* Video Preview */}
                <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
                  {stream ? (
                    <video
                      ref={videoRef}
                      autoPlay
                      muted
                      playsInline
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-white">
                      <div className="text-center">
                        <div className="text-4xl mb-2">📹</div>
                        <p>Camera Preview</p>
                      </div>
                    </div>
                  )}
                  
                  {isRecording && (
                    <div className="absolute top-4 right-4 bg-red-500 text-white px-2 py-1 rounded text-sm font-medium animate-pulse">
                      REC
                    </div>
                  )}
                </div>

                {/* Controls */}
                <div className="text-center space-y-3">
                  {!stream ? (
                    <button
                      onClick={startCamera}
                      className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
                    >
                      Enable Camera
                    </button>
                  ) : isRecording ? (
                    <div className="space-y-2">
                      <p className="text-red-600 font-medium">Recording in progress...</p>
                      <p className="text-sm text-gray-600">Look at the camera naturally</p>
                      <button
                        onClick={stopRecording}
                        className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600 transition-colors"
                      >
                        Stop Recording
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-gray-800 font-medium">Ready to record</p>
                      <p className="text-sm text-gray-600">15-second facial expression analysis</p>
                      <button
                        onClick={startRecording}
                        className="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors"
                      >
                        Start Recording
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-center space-y-4">
                <div className="w-24 h-24 mx-auto rounded-full bg-green-500 flex items-center justify-center">
                  <span className="text-white text-3xl">✅</span>
                </div>
                <p className="text-lg font-medium text-green-600">Video Recorded Successfully</p>
                
                <div className="flex gap-3 justify-center">
                  <button
                    onClick={analyzeVideo}
                    disabled={isAnalyzing}
                    className="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 disabled:opacity-50 transition-colors"
                  >
                    {isAnalyzing ? "Analyzing..." : "Analyze Video"}
                  </button>
                  <button
                    onClick={resetRecording}
                    className="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                  >
                    Record Again
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Analysis Results */}
        {analysisResult && (
          <div className="mt-6 space-y-4">
            <h3 className="text-lg font-semibold text-gray-800">Facial Analysis Results</h3>
            
            {/* Emotion Detection */}
            <div className="bg-white border rounded-lg p-4">
              <h4 className="font-medium text-gray-800 mb-3">Detected Emotions</h4>
              <div className="space-y-2">
                {Object.entries(analysisResult.faceEmotions).map(([emotion, score]) => (
                  <div key={emotion} className="flex items-center justify-between">
                    <span className="capitalize text-gray-700">{emotion}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-purple-500 h-2 rounded-full transition-all"
                          style={{ width: `${(score as number) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600 w-10">
                        {Math.round((score as number) * 100)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Facial Features */}
            <div className="bg-white border rounded-lg p-4">
              <h4 className="font-medium text-gray-800 mb-3">Facial Features Analysis</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {Math.round(analysisResult.facialFeatures.eyeContact * 100)}%
                  </div>
                  <div className="text-sm text-gray-600">Eye Contact</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {Math.round(analysisResult.facialFeatures.smileIntensity * 100)}%
                  </div>
                  <div className="text-sm text-gray-600">Smile Intensity</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600 capitalize">
                    {analysisResult.facialFeatures.overallExpression}
                  </div>
                  <div className="text-sm text-gray-600">Overall Expression</div>
                </div>
              </div>
            </div>

            {/* Insights */}
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-medium text-blue-800 mb-2">AI Insights</h4>
              <div className="text-blue-700 space-y-1">
                <p>• Your facial expressions suggest you may be experiencing some stress or concern</p>
                <p>• Consider taking breaks and practicing relaxation techniques</p>
                <p>• Good eye contact indicates engagement and awareness</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
