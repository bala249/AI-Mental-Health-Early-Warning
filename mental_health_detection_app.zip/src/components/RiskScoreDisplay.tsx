interface RiskScoreDisplayProps {
  entry: {
    riskScore: number;
    riskLevel: string;
    recommendations: string[];
    mood: string;
    sentiment: {
      label: string;
      score: number;
    };
  };
}

export function RiskScoreDisplay({ entry }: RiskScoreDisplayProps) {
  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case "low": return "from-green-400 to-green-600";
      case "moderate": return "from-yellow-400 to-yellow-600";
      case "high": return "from-orange-400 to-orange-600";
      case "critical": return "from-red-400 to-red-600";
      default: return "from-gray-400 to-gray-600";
    }
  };

  const getRiskIcon = (riskLevel: string) => {
    switch (riskLevel) {
      case "low": return "✅";
      case "moderate": return "⚠️";
      case "high": return "🚨";
      case "critical": return "🆘";
      default: return "ℹ️";
    }
  };

  const getRiskMessage = (riskLevel: string) => {
    switch (riskLevel) {
      case "low": return "You're doing great! Keep up the positive mindset.";
      case "moderate": return "Some areas need attention. Consider the recommendations below.";
      case "high": return "Your mental health needs attention. Please consider professional help.";
      case "critical": return "Immediate attention needed. Please reach out for support.";
      default: return "Assessment complete.";
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Latest Mental Health Assessment</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Risk Score Visualization */}
        <div className="space-y-4">
          <div className="text-center">
            <div className={`w-24 h-24 mx-auto rounded-full bg-gradient-to-br ${getRiskColor(entry.riskLevel)} flex items-center justify-center text-white text-2xl font-bold mb-3`}>
              {Math.round(entry.riskScore)}
            </div>
            <div className="flex items-center justify-center gap-2 mb-2">
              <span className="text-2xl">{getRiskIcon(entry.riskLevel)}</span>
              <span className="text-lg font-semibold text-gray-800 capitalize">
                {entry.riskLevel} Risk
              </span>
            </div>
            <p className="text-gray-600 text-sm">
              {getRiskMessage(entry.riskLevel)}
            </p>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className={`h-3 rounded-full bg-gradient-to-r ${getRiskColor(entry.riskLevel)} transition-all duration-500`}
              style={{ width: `${entry.riskScore}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-gray-500">
            <span>Low Risk</span>
            <span>High Risk</span>
          </div>
        </div>

        {/* Recommendations */}
        <div>
          <h3 className="font-semibold text-gray-800 mb-3">Personalized Recommendations</h3>
          <div className="space-y-3">
            {entry.recommendations.slice(0, 3).map((recommendation, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5">
                  {index + 1}
                </div>
                <p className="text-sm text-gray-700">{recommendation}</p>
              </div>
            ))}
          </div>

          {entry.riskLevel === "critical" && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-red-600 text-lg">🆘</span>
                <span className="font-semibold text-red-800">Emergency Resources</span>
              </div>
              <div className="text-sm text-red-700 space-y-1">
                <p>• Crisis Text Line: Text HOME to 741741</p>
                <p>• National Suicide Prevention Lifeline: 988</p>
                <p>• Emergency Services: 911</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
