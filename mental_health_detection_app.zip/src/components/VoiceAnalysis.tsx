import { useState, useRef } from "react";
import { useMutation, useAction } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export function VoiceAnalysis() {
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  
  const generateUploadUrl = useMutation(api.mentalHealth.generateUploadUrl);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/wav" });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      
      // Auto-stop after 20 seconds
      setTimeout(() => {
        if (mediaRecorderRef.current && isRecording) {
          stopRecording();
        }
      }, 20000);
      
    } catch (error) {
      toast.error("Could not access microphone");
      console.error(error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const analyzeAudio = async () => {
    if (!audioBlob) return;

    setIsAnalyzing(true);
    try {
      // Upload audio file
      const uploadUrl = await generateUploadUrl();
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": audioBlob.type },
        body: audioBlob,
      });
      
      if (!result.ok) {
        throw new Error("Upload failed");
      }

      const { storageId } = await result.json();

      // Simulate voice analysis (in a real app, you'd use actual AI models)
      const mockAnalysis = {
        transcription: "I'm feeling a bit overwhelmed today with work and personal responsibilities.",
        emotionScores: {
          happy: 0.1,
          sad: 0.6,
          angry: 0.1,
          fear: 0.15,
          neutral: 0.05,
        },
        speechFeatures: {
          pitch: 180, // Hz
          speed: 120, // words per minute
          tone: "subdued",
        },
      };

      setAnalysisResult({
        audioFileId: storageId,
        ...mockAnalysis,
      });

      toast.success("Voice analysis complete!");
    } catch (error) {
      toast.error("Failed to analyze audio");
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetRecording = () => {
    setAudioBlob(null);
    setAnalysisResult(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-800 mb-2">Voice Emotion Analysis</h2>
        <p className="text-gray-600 mb-6">
          Record your voice for 10-20 seconds to analyze emotional patterns in your speech
        </p>

        {/* Recording Interface */}
        <div className="bg-gray-50 rounded-xl p-6 text-center">
          {!audioBlob ? (
            <div className="space-y-4">
              <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center ${
                isRecording ? "bg-red-500 animate-pulse" : "bg-blue-500"
              }`}>
                <span className="text-white text-3xl">
                  {isRecording ? "🔴" : "🎤"}
                </span>
              </div>
              
              {isRecording ? (
                <div className="space-y-2">
                  <p className="text-lg font-medium text-red-600">Recording...</p>
                  <p className="text-sm text-gray-600">Speak naturally about how you're feeling</p>
                  <button
                    onClick={stopRecording}
                    className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600 transition-colors"
                  >
                    Stop Recording
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-lg font-medium text-gray-800">Ready to Record</p>
                  <p className="text-sm text-gray-600">Click to start voice analysis</p>
                  <button
                    onClick={startRecording}
                    className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Start Recording
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="w-24 h-24 mx-auto rounded-full bg-green-500 flex items-center justify-center">
                <span className="text-white text-3xl">✅</span>
              </div>
              <p className="text-lg font-medium text-green-600">Recording Complete</p>
              
              <div className="flex gap-3 justify-center">
                <button
                  onClick={analyzeAudio}
                  disabled={isAnalyzing}
                  className="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 disabled:opacity-50 transition-colors"
                >
                  {isAnalyzing ? "Analyzing..." : "Analyze Voice"}
                </button>
                <button
                  onClick={resetRecording}
                  className="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  Record Again
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Analysis Results */}
        {analysisResult && (
          <div className="mt-6 space-y-4">
            <h3 className="text-lg font-semibold text-gray-800">Analysis Results</h3>
            
            {/* Transcription */}
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-medium text-blue-800 mb-2">Transcription</h4>
              <p className="text-blue-700">{analysisResult.transcription}</p>
            </div>

            {/* Emotion Scores */}
            <div className="bg-white border rounded-lg p-4">
              <h4 className="font-medium text-gray-800 mb-3">Detected Emotions</h4>
              <div className="space-y-2">
                {Object.entries(analysisResult.emotionScores).map(([emotion, score]) => (
                  <div key={emotion} className="flex items-center justify-between">
                    <span className="capitalize text-gray-700">{emotion}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-500 h-2 rounded-full transition-all"
                          style={{ width: `${(score as number) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600 w-10">
                        {Math.round((score as number) * 100)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Speech Features */}
            <div className="bg-white border rounded-lg p-4">
              <h4 className="font-medium text-gray-800 mb-3">Speech Analysis</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {analysisResult.speechFeatures.pitch}Hz
                  </div>
                  <div className="text-sm text-gray-600">Average Pitch</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {analysisResult.speechFeatures.speed}
                  </div>
                  <div className="text-sm text-gray-600">Words/Minute</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600 capitalize">
                    {analysisResult.speechFeatures.tone}
                  </div>
                  <div className="text-sm text-gray-600">Tone</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
