import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  moodEntries: defineTable({
    userId: v.id("users"),
    text: v.string(),
    sentiment: v.object({
      score: v.number(), // -1 to 1 (negative to positive)
      label: v.string(), // "positive", "negative", "neutral"
      confidence: v.number(), // 0 to 1
    }),
    voiceAnalysis: v.optional(v.object({
      audioFileId: v.id("_storage"),
      transcription: v.string(),
      emotionScores: v.object({
        happy: v.number(),
        sad: v.number(),
        angry: v.number(),
        fear: v.number(),
        neutral: v.number(),
      }),
      speechFeatures: v.object({
        pitch: v.number(),
        speed: v.number(),
        tone: v.string(),
      }),
    })),
    videoAnalysis: v.optional(v.object({
      videoFileId: v.id("_storage"),
      faceEmotions: v.object({
        happy: v.number(),
        sad: v.number(),
        angry: v.number(),
        fear: v.number(),
        surprise: v.number(),
        disgust: v.number(),
        neutral: v.number(),
      }),
      facialFeatures: v.object({
        eyeContact: v.number(),
        smileIntensity: v.number(),
        overallExpression: v.string(),
      }),
    })),
    riskScore: v.number(), // 0 to 100 (low to high risk)
    riskLevel: v.string(), // "low", "moderate", "high", "critical"
    recommendations: v.array(v.string()),
    mood: v.string(), // "very_happy", "happy", "neutral", "sad", "very_sad", "anxious", "stressed"
    tags: v.optional(v.array(v.string())),
  })
    .index("by_user", ["userId"])
    .index("by_risk_level", ["riskLevel"]),

  mentalHealthProfiles: defineTable({
    userId: v.id("users"),
    averageRiskScore: v.number(),
    moodTrends: v.object({
      weekly: v.array(v.number()),
      monthly: v.array(v.number()),
    }),
    riskFactors: v.array(v.string()),
    supportContacts: v.optional(v.array(v.object({
      name: v.string(),
      phone: v.string(),
      relationship: v.string(),
    }))),
    preferences: v.object({
      enableVoiceAnalysis: v.boolean(),
      enableVideoAnalysis: v.boolean(),
      reminderFrequency: v.string(), // "daily", "weekly", "never"
    }),
    lastCheckIn: v.number(),
  })
    .index("by_user", ["userId"]),

  emergencyAlerts: defineTable({
    userId: v.id("users"),
    riskScore: v.number(),
    triggerReason: v.string(),
    status: v.string(), // "pending", "acknowledged", "resolved"
    contactsNotified: v.array(v.string()),
    moodEntryId: v.id("moodEntries"),
  })
    .index("by_user", ["userId"])
    .index("by_status", ["status"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
