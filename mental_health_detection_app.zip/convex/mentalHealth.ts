import { query, mutation, action, internalMutation, internalAction } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api, internal } from "./_generated/api";

// Text sentiment analysis using built-in OpenAI
export const analyzeSentiment = action({
  args: { text: v.string() },
  handler: async (ctx, args) => {
    const response = await fetch("https://api-inference.huggingface.co/models/cardiffnlp/twitter-roberta-base-sentiment-latest", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: args.text,
      }),
    });

    if (!response.ok) {
      // Fallback to simple keyword analysis
      const positiveWords = ["happy", "good", "great", "excellent", "wonderful", "amazing", "love", "joy", "excited"];
      const negativeWords = ["sad", "bad", "terrible", "awful", "hate", "depressed", "anxious", "worried", "scared"];
      
      const text = args.text.toLowerCase();
      let score = 0;
      
      positiveWords.forEach(word => {
        if (text.includes(word)) score += 0.1;
      });
      
      negativeWords.forEach(word => {
        if (text.includes(word)) score -= 0.1;
      });
      
      return {
        score: Math.max(-1, Math.min(1, score)),
        label: score > 0.1 ? "positive" : score < -0.1 ? "negative" : "neutral",
        confidence: Math.abs(score),
      };
    }

    const result = await response.json();
    const sentiment = result[0];
    
    return {
      score: sentiment.label === "LABEL_2" ? 1 : sentiment.label === "LABEL_0" ? -1 : 0,
      label: sentiment.label === "LABEL_2" ? "positive" : sentiment.label === "LABEL_0" ? "negative" : "neutral",
      confidence: sentiment.score,
    };
  },
});

// Calculate risk score based on multiple factors
export const calculateRiskScore = action({
  args: {
    sentiment: v.object({
      score: v.number(),
      label: v.string(),
      confidence: v.number(),
    }),
    voiceAnalysis: v.optional(v.object({
      emotionScores: v.object({
        happy: v.number(),
        sad: v.number(),
        angry: v.number(),
        fear: v.number(),
        neutral: v.number(),
      }),
      speechFeatures: v.object({
        pitch: v.number(),
        speed: v.number(),
        tone: v.string(),
      }),
    })),
    videoAnalysis: v.optional(v.object({
      faceEmotions: v.object({
        happy: v.number(),
        sad: v.number(),
        angry: v.number(),
        fear: v.number(),
        surprise: v.number(),
        disgust: v.number(),
        neutral: v.number(),
      }),
    })),
  },
  handler: async (ctx, args) => {
    let riskScore = 50; // Base score

    // Text sentiment impact (40% weight)
    const sentimentImpact = (1 - args.sentiment.score) * 20; // Convert -1,1 to 0,40
    riskScore += sentimentImpact;

    // Voice analysis impact (30% weight)
    if (args.voiceAnalysis) {
      const negativeEmotions = args.voiceAnalysis.emotionScores.sad + 
                              args.voiceAnalysis.emotionScores.angry + 
                              args.voiceAnalysis.emotionScores.fear;
      riskScore += negativeEmotions * 30;
    }

    // Video analysis impact (30% weight)
    if (args.videoAnalysis) {
      const negativeEmotions = args.videoAnalysis.faceEmotions.sad + 
                              args.videoAnalysis.faceEmotions.angry + 
                              args.videoAnalysis.faceEmotions.fear;
      riskScore += negativeEmotions * 30;
    }

    // Ensure score is between 0-100
    riskScore = Math.max(0, Math.min(100, riskScore));

    const riskLevel = riskScore >= 80 ? "critical" : 
                     riskScore >= 60 ? "high" : 
                     riskScore >= 40 ? "moderate" : "low";

    const recommendations = generateRecommendations(riskScore, args.sentiment.label);

    return { riskScore, riskLevel, recommendations };
  },
});

function generateRecommendations(riskScore: number, sentimentLabel: string): string[] {
  const recommendations = [];

  if (riskScore >= 80) {
    recommendations.push("Consider reaching out to a mental health professional immediately");
    recommendations.push("Contact a crisis helpline: 988 (Suicide & Crisis Lifeline)");
    recommendations.push("Reach out to a trusted friend or family member");
  } else if (riskScore >= 60) {
    recommendations.push("Schedule an appointment with a counselor or therapist");
    recommendations.push("Practice deep breathing exercises");
    recommendations.push("Consider talking to someone you trust");
  } else if (riskScore >= 40) {
    recommendations.push("Try meditation or mindfulness exercises");
    recommendations.push("Go for a walk or do light exercise");
    recommendations.push("Journal about your feelings");
  } else {
    recommendations.push("Keep up the positive mindset!");
    recommendations.push("Continue healthy habits like exercise and good sleep");
    recommendations.push("Consider helping others to boost your mood");
  }

  if (sentimentLabel === "negative") {
    recommendations.push("Practice gratitude by listing 3 things you're thankful for");
    recommendations.push("Listen to uplifting music or podcasts");
  }

  return recommendations;
}

// Create mood entry
export const createMoodEntry = mutation({
  args: {
    text: v.string(),
    sentiment: v.object({
      score: v.number(),
      label: v.string(),
      confidence: v.number(),
    }),
    riskScore: v.number(),
    riskLevel: v.string(),
    recommendations: v.array(v.string()),
    mood: v.string(),
    voiceAnalysis: v.optional(v.object({
      audioFileId: v.id("_storage"),
      transcription: v.string(),
      emotionScores: v.object({
        happy: v.number(),
        sad: v.number(),
        angry: v.number(),
        fear: v.number(),
        neutral: v.number(),
      }),
      speechFeatures: v.object({
        pitch: v.number(),
        speed: v.number(),
        tone: v.string(),
      }),
    })),
    videoAnalysis: v.optional(v.object({
      videoFileId: v.id("_storage"),
      faceEmotions: v.object({
        happy: v.number(),
        sad: v.number(),
        angry: v.number(),
        fear: v.number(),
        surprise: v.number(),
        disgust: v.number(),
        neutral: v.number(),
      }),
      facialFeatures: v.object({
        eyeContact: v.number(),
        smileIntensity: v.number(),
        overallExpression: v.string(),
      }),
    })),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const entryId = await ctx.db.insert("moodEntries", {
      userId,
      ...args,
    });

    // Check if we need to create an emergency alert
    if (args.riskScore >= 80) {
      await ctx.db.insert("emergencyAlerts", {
        userId,
        riskScore: args.riskScore,
        triggerReason: `High risk score: ${args.riskScore}`,
        status: "pending",
        contactsNotified: [],
        moodEntryId: entryId,
      });
    }

    // Update user's mental health profile
    await ctx.scheduler.runAfter(0, internal.mentalHealth.updateUserProfile, { userId });

    return entryId;
  },
});

// Get user's mood entries
export const getUserMoodEntries = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("moodEntries")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(args.limit ?? 20);
  },
});

// Get user's mental health profile
export const getUserProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    return await ctx.db
      .query("mentalHealthProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();
  },
});

// Update user profile (internal function)
export const updateUserProfile = internalAction({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const recentEntries = await ctx.runQuery(api.mentalHealth.getRecentEntriesForUser, {
      userId: args.userId,
    });

    if (recentEntries.length === 0) return;

    const averageRiskScore = recentEntries.reduce((sum, entry) => sum + entry.riskScore, 0) / recentEntries.length;
    
    const weeklyScores = recentEntries.slice(0, 7).map(entry => entry.riskScore);
    const monthlyScores = recentEntries.slice(0, 30).map(entry => entry.riskScore);

    const existingProfile = await ctx.runQuery(api.mentalHealth.getUserProfileById, {
      userId: args.userId,
    });

    if (existingProfile) {
      await ctx.runMutation(internal.mentalHealth.updateProfile, {
        profileId: existingProfile._id,
        averageRiskScore,
        weeklyScores,
        monthlyScores,
      });
    } else {
      await ctx.runMutation(internal.mentalHealth.createProfile, {
        userId: args.userId,
        averageRiskScore,
        weeklyScores,
        monthlyScores,
      });
    }
  },
});

// Helper queries and mutations for internal use
export const getRecentEntriesForUser = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("moodEntries")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .order("desc")
      .take(30);
  },
});

export const getUserProfileById = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("mentalHealthProfiles")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();
  },
});

export const updateProfile = internalMutation({
  args: {
    profileId: v.id("mentalHealthProfiles"),
    averageRiskScore: v.number(),
    weeklyScores: v.array(v.number()),
    monthlyScores: v.array(v.number()),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.profileId, {
      averageRiskScore: args.averageRiskScore,
      moodTrends: {
        weekly: args.weeklyScores,
        monthly: args.monthlyScores,
      },
      lastCheckIn: Date.now(),
    });
  },
});

export const createProfile = internalMutation({
  args: {
    userId: v.id("users"),
    averageRiskScore: v.number(),
    weeklyScores: v.array(v.number()),
    monthlyScores: v.array(v.number()),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("mentalHealthProfiles", {
      userId: args.userId,
      averageRiskScore: args.averageRiskScore,
      moodTrends: {
        weekly: args.weeklyScores,
        monthly: args.monthlyScores,
      },
      riskFactors: [],
      preferences: {
        enableVoiceAnalysis: true,
        enableVideoAnalysis: true,
        reminderFrequency: "daily",
      },
      lastCheckIn: Date.now(),
    });
  },
});

// Generate upload URL for audio/video files
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
